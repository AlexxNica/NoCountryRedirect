// -----------------------------------------------------------------
// file:	background.js
// what:	does all the work for this extension
// started: 2012.08.13
// -----------------------------------------------------------------


// to do : options menu for tuning domain checking on and off
// to do : log what tab id has been ncr'ified - cut down on loops / checking - display icon correctly


// -----
// simple function that prints debugging messages
// -----
function debug(message){
	var doDebug = false;										// if 'true' then print message, if 'false' do not

	if (doDebug){
		console.log("DEBUG : " + message);
	}
}


// Hello, World!
debug("Hello, World! - from background.js");


// -----
// build an array with URLs that are to be checked and NCR'ified if possible
// -----
var urlsToCheck = new Array();
urlsToCheck[0] = ".blogspot.";
urlsToCheck[1] = ".google.";


// -----
// main function that checks URLs, and NCR'ifies those who are to be NCR'ified
// -----
function urlCheck(tabId, changeInfo, tab) {
	var newUrl;
	var tldCcRegexp = /\.\w{2,3}(\.\w{2,3})?\//;					// regular expression that represents a country specific tld plus a slash (like '.jp/' or '.no/' or '.co.uk') - note that all URLs given by tab.url will end with a slash.

	debug("urlCheck()");

	// we only continue if given URL doesn't contain "/ncr/" and is not a .com domain
	if ( (tab.url.indexOf("/ncr/") == -1) && (tab.url.indexOf(".com/") == -1) ){
		for(var i = 0; i < urlsToCheck.length; i++) {
			//debug("urlsToCheck["+i+"] = " + urlsToCheck[i]);
			//debug("tab.url = " + tab.url);					// alternative: encodeURIComponent(tab.url);
			//debug("tab.title = " + tab.title);				// alternative: encodeURIComponent(tab.title)

			// if we find the pattern given in our urlsToCheck
			if ( (tab.url.indexOf(urlsToCheck[i]) > -1) ){
				debug("candidate URL : tab.url = " + tab.url + " (matching : urlsToCheck["+i+"] = '"+ urlsToCheck[i] +"')");
				newUrl = tab.url;
				newUrl = newUrl.replace(tldCcRegexp, ".com/ncr/");
				
				if (newUrl.match(/.com\/ncr\/$/)){				// if the url ends with ".com/nrc/" we have to remove the last slash (because 'www.google.com/nrc/' is not a valid domain, but 'www.google.com/nrc' (without the last slash) is valid)
					newUrl = newUrl.replace(".com/ncr/", ".com/ncr");
				}
				
				//newUrl = newUrl.replace("http://www.google.com", "https://www.google.com");	// if 'http://google.com' then replace with 'https://google.com' ('http://google.com/ncr' is not working)
				//newUrl = newUrl.replace('//', '/');				// we might have two slashes at the end sometimes, remove one of them
				debug("newUrl = " + newUrl);
				chrome.tabs.update(tab.id, {url: newUrl});		// update tab URL
				//i = 999;										// will cause us jumping out of the for loop
				break; // TESTING BREAK IN STEAD... should work!
			}
	
			// check if we shall display the NCR icon in the browser's URL field
/*
			if ( (tab.url.indexOf(urlsToCheck[i]) > -1) && (tab.url.indexOf('.com/') > -1) ){
				debug("show page action for URL : " + tab.url);
				chrome.pageAction.show(tabId);					// show the page action (the NCR icon)
			}
*/
		}
	}

	// quick fix for displaying icon without using local storage. will be improved in future version of this extension
	for(var i = 0; i < urlsToCheck.length; i++) {
		if ( (tab.url.indexOf(urlsToCheck[i]) > -1) && (tab.url.indexOf('.com/') > -1) ){
			debug("show page action for URL : " + tab.url);
			chrome.pageAction.show(tabId);					// show the page action (the NCR icon)
		}
	}
	
}


// -----
// Listen for any changes to the URL of any tab.
// -----
chrome.tabs.onUpdated.addListener(urlCheck);

